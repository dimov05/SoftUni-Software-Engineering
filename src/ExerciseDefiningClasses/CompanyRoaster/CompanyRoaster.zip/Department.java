package ExerciseDefiningClasses;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Department {
    private String name;
    private List<Employee> employeeList;

    public List<Employee> getEmployeeList() {
        return Collections.unmodifiableList(employeeList);
    }

    public Department() {
        this.employeeList = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void addEmployee(Employee employee) {
        this.employeeList.add(employee);
    }

    public double getAvgSalary() {
        double avrSalary = 0.0;
        for (Employee employee : employeeList) {
            avrSalary += employee.getSalary();
        }
        return avrSalary / this.employeeList.size();
    }
}
