package ExerciseIteratorsAndComparators.ListyIterator;

import java.util.List;

public class ListyIterator {
    static int a;
    private List<String> list;
    private int index;

    public ListyIterator(List<String> data) {
        this.list = data;
    }

    public void Print() {
        validatePrint();
        System.out.println(this.list.get(this.index));
    }

    private void validatePrint() {
        if (this.list.isEmpty()) {
            throw new IllegalStateException("Invalid Operation!");
        }
    }

    public boolean Move() {
        if (HasNext()) {
            index++;
            return true;
        }
        return false;
    }

    public boolean HasNext() {
        return index < list.size() - 1;
    }
}
