package GenericsExercises.GenericsBox.CustomList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomList<T extends Comparable<T>> {

    private List<T> values;

    public CustomList() {
        this.values = new ArrayList<>();
    }

    private static void isEmpty(boolean empty) {
        if (empty) {
            throw new IllegalArgumentException();
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        this.values.forEach(e -> sb.append(e).append(System.lineSeparator()));
        return sb.toString().trim();
    }
    public T getMin() {
        isEmpty(this.values.isEmpty());
        return Collections.min(this.values);
    }

    public T getMax() {
        isEmpty(this.values.isEmpty());
        return Collections.max(this.values);
    }

    public void add(T value) {
        this.values.add(value);
    }

    public void remove(int index) {
        this.values.remove(index);
    }

    public boolean contains(T value) {
        return this.values.contains(value);
    }

    public void swap(int indexFirst, int indexSecond) {
        T first = this.values.get(indexFirst);
        this.values.set(indexFirst, this.values.get(indexSecond));
        this.values.set(indexSecond, first);
    }

    public long countGreaterThan(T toCompare) {
        return this.values.stream()
                .filter(e -> e.compareTo(toCompare) > 0).count();
    }

    public int getSize() {
        return this.values.size();
    }

    public T get(int i) {
        return this.values.get(i);
    }
}


