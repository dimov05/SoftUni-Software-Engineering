public class Main {
    public static void main(String[] args) {
        Jar<Integer> picklesJar = new Jar<>();
    }
}
