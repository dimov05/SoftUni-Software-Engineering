public class Main {
    public static void main(String[] args) {
        Scale<String> stringScale = new Scale<>("A","A");
        System.out.println(stringScale.getHeavier());
    }
}
